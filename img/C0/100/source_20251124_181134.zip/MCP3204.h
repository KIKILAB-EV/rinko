#include "hardware/spi.h"
#include "hardware/gpio.h"

/**
 * MCP3204 ADCコントローラークラス
 * 12bit 4チャンネル SPI ADC（MCP3204）を制御するためのクラス
 */
struct MCP3204{
    constexpr static double VREF = 5.0;                    // 基準電圧 [V]
    constexpr static int ADC_RESOLUTION = 4096-1;          // 12bit ADC分解能 (4095)
    
    using spi_type = spi_inst_t*;

    // SPI通信用ピン番号
    int pin_miso = 4;   // Master In Slave Out（データ入力）
    int pin_mosi = 3;   // Master Out Slave In（データ出力）
    int pin_sck = 2;    // Serial Clock（クロック）
    int pin_cs = 5;     // Chip Select（チップ選択）
    spi_type spi_port = spi0;  // 使用するSPIポート

    /**
     * MCP3204の初期化
     * @param pin_sck クロックピン番号（デフォルト：2）
     * @param pin_mosi データ出力ピン番号（デフォルト：3）
     * @param pin_miso データ入力ピン番号（デフォルト：4）
     * @param pin_cs チップ選択ピン番号（デフォルト：5）
     * @param spi_port 使用するSPIポート（デフォルト：spi0）
     * @param freq_MHZ SPI通信周波数[MHz]（デフォルト：1MHz）
     */
    void init(int pin_sck = 2, int pin_mosi=3, int pin_miso=4, int pin_cs=5, spi_type spi_port = spi0, float freq_MHZ = 1) {
        // ピン番号を保存
        this->pin_miso = pin_miso;
        this->pin_mosi = pin_mosi;
        this->pin_sck = pin_sck;
        this->pin_cs = pin_cs;
        this->spi_port = spi_port;

        // SPI初期化（指定周波数で設定）
        spi_init(spi_port, freq_MHZ * 1e6);

        // SPIピンの機能設定
        gpio_set_function(pin_miso, GPIO_FUNC_SPI);  // MISO
        gpio_set_function(pin_mosi, GPIO_FUNC_SPI);  // MOSI
        gpio_set_function(pin_sck, GPIO_FUNC_SPI);   // SCK
        
        // CS pin設定（手動制御用のデジタル出力として設定）
        gpio_init(pin_cs);
        gpio_set_dir(pin_cs, GPIO_OUT);
        gpio_put(pin_cs, 1);  // 初期状態はHigh（非選択状態）
    }

    /**
     * 指定チャンネルのADC値を読み取り
     * @param channel ADCチャンネル（0-3）
     * @return 12bit ADC値（0-4095）、無効チャンネルの場合は0
     */
    uint16_t read_channel(uint8_t channel){
        if (channel > 3) return 0;  // チャンネル0-3のみ有効

        uint8_t tx_data[3];  // 送信データ配列
        uint8_t rx_data[3];  // 受信データ配列
        
        // MCP3204コマンド構築（シングルエンド入力モード）
        // Start bit (1) + Single/Diff (1) + D2-D0 (channel) + Don't care
        tx_data[0] = 0x06 | (channel >> 2);        // 000001(start)1(single)xxx
        tx_data[1] = (channel << 6);               // チャンネル選択ビット
        tx_data[2] = 0x00;                         // ダミーデータ
        
        // チップ選択（CS Low = アクティブ）
        gpio_put(this->pin_cs, 0);
        sleep_us(1);  // セットアップ時間待機
        
        // SPI通信実行（3バイト送受信）
        spi_write_read_blocking(this->spi_port, tx_data, rx_data, 3);
        
        // チップ非選択（CS High = 非アクティブ）
        gpio_put(this->pin_cs, 1);
        sleep_us(1);  // ホールド時間待機
        
        // 12bitデータを抽出（受信データの下位12bit）
        uint16_t adc_value = ((rx_data[1] & 0x0F) << 8) | rx_data[2];
    
        return adc_value;
    }

    /**
     * 指定チャンネルの電圧値を読み取り
     * @param channel ADCチャンネル（0-3）
     * @return 電圧値[V]（0.0 - VREF）
     */
    float voltage(int channel) {
        uint16_t adc_value = read_channel(channel);  // ADC値取得
        // ADC値を電圧値に変換（VREF基準で正規化）
        return (static_cast<float>(adc_value) * VREF) / ADC_RESOLUTION;
    }
};