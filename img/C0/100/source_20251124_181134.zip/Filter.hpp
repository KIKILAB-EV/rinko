struct LPFilter {
	double value[2] = {0};
	double a;

	LPFilter(double _a, double init = 0){ a=_a; value[0] = value[1] = init;}

	double compute(double x){
		value[0] = value[1];
		value[1] = a * value[0] + (1 - a) * x;
		return value[1];
	}
};