#include "Constant.hpp"
#include "Params.hpp"

double average(double *arr, int num) {
	double sum = 0;
	int i = 0;
	for (; i < num; i++)
	{
		sum += arr[i];
	}
	return sum / num;
}