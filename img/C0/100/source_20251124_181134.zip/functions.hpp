#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include "Constant.hpp"
#include "Params.hpp"

/// @brief 範囲内に丸める
/// @param value 入力値
/// @param low 下限値
/// @param high 上限値
/// @return 丸められた入力値
constexpr double clamp(double value, double low, double high)
{
	return value > high ? high : value < low ? low
											: value;
}

/// @brief 平均値を計算
/// @param arr 入力配列
/// @param num 配列長
/// @return 平均値
double average(double *arr, int num);

/// @brief 回転数から角速度へ変換
/// @param N 回転数(rpm)
/// @return 角速度
constexpr double OmegaFromN(double N)
{
	return 2 * PI * N / 60;
}

/// @brief トルクから減速度へ変換
/// @param torque トルク
/// @return 減速度
constexpr double T2D(double torque)
{
	return torque * DPT;
}

/// @brief 減速度からトルクへ変換
/// @param deceleration 減速度
/// @return トルク
constexpr double D2T(double deceleration)
{
	return deceleration * TPD;
}

/// @brief 回転数から秒速へ変換
/// @param N 回転数(rpm)
/// @return 秒速
constexpr double N2V(double N)
{
	return WHEEL_R / GEAR * OmegaFromN(N); //[m/s] ギア比を加味
}

/// @brief 最大減速度を計算
/// @param N 回転数(rpm)
/// @return 最大減速度
constexpr double CalcDMax(double N)
{
	return 0.1004 * N2V(N) + 0.9163;
}

/// @brief 最大減速度を計算
/// @param N 回転数(rpm)
/// @return 最大減速度
constexpr double CalcTMax(double N)
{
	return TPD * (0.1004 * N2V(N) + 0.9163);
}

constexpr double CalcTorque(double I, double N){
	return 0.689 * I - 1.0e-5 * N + 0.00576; 
}

#endif // FUNCTIONS_HPP