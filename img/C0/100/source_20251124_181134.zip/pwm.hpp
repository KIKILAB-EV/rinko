#ifndef PWM_H
#define PWM_H
#include "hardware/pwm.h"
#include "Constant.hpp"

/**
 * PWM制御クラス
 * Raspberry Pi PicoのハードウェアPWMを制御するためのクラス
 */
class PWM{
    int m_gpio;         // PWM出力用GPIOピン番号
    uint m_slice_num;   // PWMスライス番号（8個のPWMスライスのうちどれか）
    uint m_channel;     // PWMチャンネル（A or B）
    double m_freq;      // PWM周波数 [Hz]
    int m_resolution;   // PWM分解能（デューティ比の刻み数）

public:
    /**
     * PWM初期化
     * @param gpio PWM出力するGPIOピン番号
     * @param freq PWM周波数 [Hz]
     * @param resolution PWM分解能（例：10000なら0.01%刻みでデューティ比設定可能）
     */
    void init(int gpio, double freq, int resolution){
        m_gpio = gpio;
        // GPIOピンからPWMスライス番号を取得（GPIO0,1→slice0, GPIO2,3→slice1...）
        m_slice_num = pwm_gpio_to_slice_num(gpio);
        // チャンネル決定（偶数GPIO→チャンネルA, 奇数GPIO→チャンネルB）
        m_channel = gpio % 2 == 0 ? PWM_CHAN_A : PWM_CHAN_B;
        m_freq = freq;
        m_resolution = resolution;
        
        // GPIOピンをPWM機能に設定
        gpio_set_function(gpio, GPIO_FUNC_PWM);
        
        // PWMクロック分周比設定（目標周波数になるよう調整）
        // システムクロック / ((分解能+1) * 目標周波数) = 分周比
        pwm_set_clkdiv(m_slice_num, PICO_FREQ / ((resolution+1) * freq));
        
        // PWMカウンタの最大値設定（分解能-1）
        pwm_set_wrap(m_slice_num, resolution-1);
        
        // 初期デューティ比を0%に設定
        pwm_set_chan_level(m_slice_num, m_channel, 0);
        
        // PWM出力開始
        pwm_set_enabled(m_slice_num, true);
    }

    /**
     * PWMデューティ比設定
     * @param value デューティ比（0.0-1.0）0.0=0%, 1.0=100%
     */
    void set(double value){
        // デューティ比を分解能に合わせてスケール変換
        // 例：value=0.5, resolution=10000 → 5000カウントでHigh出力
        pwm_set_chan_level(m_slice_num, m_channel, value * m_resolution);
    }
};

#endif // PWM_H