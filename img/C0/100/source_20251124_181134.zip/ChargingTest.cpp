#include <math.h>
#include <stdio.h>

#include "pico/stdlib.h"
#include "hardware/timer.h"

#include "adc.hpp"
#include "pwm.hpp"
#include "Constant.hpp"
#include "Params.hpp"
#include "PIControl.hpp"
#include "functions.hpp"
#include "Filter.hpp"
#include "gpio.hpp"
#include "MCP3204.h"

static constexpr double StartN = 1000; // 充電開始回転数

namespace input{
    extern GPIO toggle;      // トグルスイッチ
    extern MCP3204 ADC;      // ADC（アナログ-デジタル変換器）
}
namespace output{
    extern PWM duty_cl, duty_bst; // PWM出力（クラッチ・昇圧用）
    extern GPIO LED;              // LED出力
	extern GPIO Relay;            // 充電特性用リレー
}

// 充電特性試験関数
void ChargeTest(){
    // トグルスイッチがONなら停止
    if(input::toggle.read() == true){
        output::Relay.write(0); // リレーOFF
        return;
    }

    double N = input::ADC.voltage(0) * 500.0; // 500rpm/V
    if(N < StartN){
        output::Relay.write(1); // リレーON
    }
    else{
        output::Relay.write(0); // リレーOFF
    }
}