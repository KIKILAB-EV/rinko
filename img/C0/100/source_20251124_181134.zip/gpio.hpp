#ifndef GPIO_H
#define GPIO_H
#include "pico/stdlib.h"
#include "hardware/gpio.h"

/**
 * GPIO制御クラス
 * Raspberry Pi Picoのデジタル入出力ピンを制御するためのラッパークラス
 */
class GPIO{
private:
    uint pin; // 使用するGPIOピン番号

public:
    /**
     * GPIOピンの初期化
     * @param pin GPIOピン番号
     * @param input true:入力モード, false:出力モード（デフォルト）
     * @param pull_up true:プルアップ抵抗を有効にする（入力モード時のみ有効）
     */
    void init(uint pin, bool input = false, bool pull_up = false){
        this->pin = pin;
        gpio_init(pin);                                        // GPIOピンを初期化
        gpio_set_dir(pin, input ? GPIO_IN : GPIO_OUT);        // 入出力方向を設定
        if(input && pull_up){
            gpio_pull_up(pin);                                // 内部プルアップ抵抗を有効化
        }
    }
    
    /**
     * GPIOピンに値を出力（出力モード時のみ有効）
     * @param value true:HIGH(3.3V), false:LOW(0V)
     */
    void write(bool value){
        gpio_put(pin, value);
    }
    
    /**
     * GPIOピンの値を読み取り（入力モード時に使用）
     * @return true:HIGH状態, false:LOW状態
     */
    bool read(){
        return gpio_get(pin);
    }
};

#endif // GPIO_H