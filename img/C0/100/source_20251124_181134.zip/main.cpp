/**
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#include <math.h>
#include <stdio.h>

#include "pico/stdlib.h"
#include "hardware/timer.h"

#include "adc.hpp"
#include "pwm.hpp"
#include "Constant.hpp"
#include "Params.hpp"
#include "PIControl.hpp"
#include "functions.hpp"
#include "Filter.hpp"
#include "gpio.hpp"
#include "MCP3204.h"

// トルクの平均化/フィルタリングの選択
// #define TORQUE_AVERAGE
#define TORQUE_FILTER

// 昇圧制御の有効/無効
#define BOOST_FLAG 1

// 比例ゲイン切り替えの有効/無効
#define KP_SWITCH_FLAG 1

// 充電特性試験
#define CHARGE_TEST 0

constexpr int T_NUM = 50;
#define BETWEEN(x, a, b) ((a) <= (x) && (x) < (b))

// 入力系の名前空間
namespace input{
    GPIO toggle;      // トグルスイッチ
    MCP3204 ADC;      // ADC（アナログ-デジタル変換器）
}
// 出力系の名前空間
namespace output{
    PWM duty_cl, duty_bst; // PWM出力（クラッチ・昇圧用）
    GPIO LED;              // LED出力
	GPIO Relay;            // 充電特性用リレー
}

#define CONTROL_BY_DUTY 0
#define CONTROL_BY_N 1

// 昇圧区間の比例ゲイン調整関数
void ControleKP_CL(double duty, double step, PIDControl* pi, double N){
    double difKp = 0;
#if CONTROL_BY_DUTY
    // Duty値によるKP調整
    if (BETWEEN(duty, 1.5, 1.8)) { difKp = 2.8; }
    else if (BETWEEN(duty, 1.8, 2.2)) { difKp = 0.6; }
    else if (BETWEEN(duty, 2.2, 2.8)) { difKp = 0.2; }
    else if (BETWEEN(duty, 2.8,3.7)) { difKp = 1.8; }
    else if (BETWEEN(duty, 3.9, 4.07)) { difKp = -0.8; }
#elif CONTROL_BY_N
#if C100
    // 回転数によるKP調整
    if (BETWEEN(N, 930, START_N))
	{
		difKp = 0.15;
	}
	else if (BETWEEN(N, 700, 930))
	{
		difKp = 0.015;
	}
	else if (BETWEEN(N, 640, 700))
	{
		difKp = 0.4;
	}
	else if (BETWEEN(N, 560, 640))
	{
		difKp = 0.01;
	}
#else
    // 回転数によるKP調整
    if (BETWEEN(N, 930, START_N))
	{
		difKp = 0.15;
	}
	else if (BETWEEN(N, 700, 930))
	{
		difKp = 0.015;
	}
	else if (BETWEEN(N, 640, 700))
	{
		difKp = 0.4;
	}
	else if (BETWEEN(N, 560, 640))
	{
		difKp = 0.01;
	}
#endif
#endif 
    pi->KP += difKp * step;
}

// 昇圧側の比例ゲイン調整関数
void ControleKP_BST(double duty, double step, PIDControl *pi, double N)
{
    if (duty < 0.9)
    {
        double difKp = 0;
#if C100
        if (N >= 430) { difKp = 0; pi->KP = KP_BST; }
        else if (BETWEEN(N, 240, 370)) { difKp = -0.01; }
        else if (BETWEEN(N, 200, 240)) { difKp = -0.01; }
        else if (BETWEEN(N, 180, 200)) { difKp = -0.12; }
        else if (BETWEEN(N, 0, 180)) { difKp = -0.2; }
#else
        if (N >= 430) { difKp = 0; pi->KP = KP_BST; }
        else if (BETWEEN(N, 240, 370)) { difKp = -0.8; }
        else if (BETWEEN(N, 200, 240)) { difKp = -0.7; }
        else if (BETWEEN(N, 180, 200)) { difKp = -0.12; }
        else if (BETWEEN(N, 0, 180)) { difKp = -0.2; }
        pi->KP += difKp * step;
#endif
        // KPの下限チェック
        // if (BETWEEN(N, 0, 180)) {
        //     if (pi->KP < 0.05) { pi->KP = 0.05; }
        // }
        if (pi->KP < 0) { pi->KP = 0; }
    }
    else{
        // 何もしない
    }
}

// モード定義
enum Mode{
    NORMAL_DECELERATION = 0, // 自然減速
    JERK_MODE = 1,           // ジャーク区間
    CURRENT_LIMIT = 2,       // 電流制限モード
    BOOST = 3,               // 昇圧モード
    STOPPED = -1,            // 停止
    //END = -2
};

// タイマーコールバック関数宣言
bool timer_callback(repeating_timer *t);

#if CHARGE_TEST
extern void ChargeTest();
#endif

// メイン関数
int main(){
    stdio_init_all(); // 標準入出力初期化
    adc_init();       // ADC初期化

    input::toggle.init(15, true, false); // トグルスイッチ初期化
    input::ADC.init();                   // ADC初期化

    output::duty_cl.init(10, PWM_FREQ_CL, 10000);   // クラッチPWM初期化 分解能10000
    output::duty_bst.init(13, PWM_FREQ_BST, 10000); // 昇圧PWM初期化 分解能10000
    output::LED.init(25);                           // LED初期化
    output::LED.write(0);                           // LED消灯
	output::Relay.init(0);							// 充電特性用リレー初期化
	output::Relay.write(0);							// リレーOFF

    // タイマー設定（SAMPLE_FREQ周期でコールバック実行）
#if !CHARGE_TEST
    repeating_timer timer;
    add_repeating_timer_us(-1e6/SAMPLE_FREQ, timer_callback, NULL, &timer);
#endif

    while(1){
#if CHARGE_TEST
		ChargeTest();
#endif
	}
}

// 制御タイマーコールバック関数
bool timer_callback(repeating_timer *t){
    static Mode mode = NORMAL_DECELERATION; // 初期モード
    constexpr double step = 1.0 / SAMPLE_FREQ;

    // トグルスイッチがONなら停止
    if(input::toggle.read() == true){
        output::LED.write(0);
        return true;
    }
    output::LED.write(1);

    static double now = 0;
    now += step;

    double torque, allT = Flywheel_Tc;
    double input_t, f_input_t; // 入力トルク電流
    double N, omega, d;

    static double DutyCL = 0, DutyBST = 0;

    static bool dec_kp_f = false;
    static double refT = 0, T_MAX = 0;
#if KP_SWITCH_FLAG
    static PIDControl PI_CL(KP_CL1, KI_CL, 0, STEP_CL, 0, 1.1), PI_BST(KP_BST, KI_BST, 0, STEP_BST, 0, 0.95);
#else
    static PIDControl PI_CL(KP_CL1, KI_CL, 0, STEP_CL, 0, 1.1), PI_BST(KP_BST, KI_BST, 0, STEP_BST, 0, 0.95);
#endif

    // 回転数・速度・加速度計算
    {
        N = input::ADC.voltage(0) * 500.0; // 500rpm/V
        omega = OmegaFromN(N);
#if 1
        {
            static LPFilter filter(0.91, N);
            N = filter.compute(N);
        }
#endif
#if 1
        {
            constexpr int NUM = DELAY_D * SAMPLE_FREQ + 1;
            constexpr double F = 20;
            constexpr double K = STEP / (STEP + 1/(2*PI*F));
            static double n[NUM] = {N};
            static int cnt = 0;
            static double old_d = 0;
            double v = (WHEEL_R / GEAR) * omega;
            n[cnt] = v;
            cnt++;
            cnt %= NUM;
            d = -(v - n[cnt]) * (1 / DELAY_D);

            d = old_d + K * (d - old_d);
            old_d = d;

            static LPFilter filter(0.91);
            d = filter.compute(d);
        }
#endif
    }
    // トルク電流取得・フィルタリング
    {
        static LPFilter filter(0.91);
        constexpr double rate = 1 / 0.1; // 0.1V/A
        input_t = input::ADC.voltage(1) * rate;
        f_input_t = filter.compute(input_t);
#if defined TORQUE_FILTER || defined TORQUE_FILTER
        torque = CalcTorque(input_t, N); // トルク計算
#else
        torque = CalcTorque(f_input_t, N);
#endif 
    }
    // モードが停止でなければ制御処理
    if(mode != STOPPED){
        {
#ifdef TORQUE_AVERAGE
            // トルクの平均化
            static int cntT = 0;
            static double Torque[T_NUM];
            {
                static bool initflag = false;
                if (!initflag)
                {
                    int i;
                    for (i = 0; i < T_NUM; i++)
                    {
                        Torque[i] = 0;
                    }
                    initflag = true;
                }
            }
            Torque[cntT] = torque;
            cntT++;
            cntT %= T_NUM;
            allT += average(&Torque[0], T_NUM);
#elif defined TORQUE_FILTER
            // トルクのフィルタリング
            static LPFilter filter(0.91);
            allT += filter.compute(torque);
#endif
            allT += Flywheel_K1 * omega; // フライホイール損失加算

            // 停止判定
            if (N <= 20)
            {
                if (d < 0.2){
                    allT = 0;
                    mode = STOPPED;
                }
            }
        }
        // 通常減速→ジャーク区間への遷移判定
        if (mode == NORMAL_DECELERATION)
        {
            if (N < START_N)
            {
                mode = JERK_MODE;
                refT = allT;
                T_MAX = CalcTMax(N);
            }
        }

        // ジャークモードの処理
        if (mode == JERK_MODE)
        {
#if KP_SWITCH_FLAG
            if (T_MAX > refT) // ジャーク区間
            {
                constexpr double DEC_TIME = 0.02;
                refT += D2T(JERK) * step;
                if (T_MAX - (D2T(JERK) * DEC_TIME) < refT)
                {
                    PI_CL.KP -= (KP_CL1 - KP_CL2) * (step / DEC_TIME);
                    if (PI_CL.KP <= KP_CL2)
                    {
                        PI_CL.KP = KP_CL2;
						dec_kp_f = true;
						refT = T_MAX;
                        mode = CURRENT_LIMIT;

                    }
                }
                else
                {
                    PI_CL.KP = KP_CL1;
                }
            }
            else
            {
                if (T_MAX < refT)
                {
                    refT = T_MAX;
                }
                if (!dec_kp_f)
                {
                    PI_CL.KP = KP_CL2;
                    dec_kp_f = true;
                }
            }
#else
            if (T_MAX > refT) // ジャーク区間
            {
				// 目標トルクにジャーク分を加算
                refT += D2T(JERK) * step;
            }
            else
            {
				// 目標トルクが最大トルクを超えたら最大トルクに設定して電流制限モードへ遷移
                refT = T_MAX;
                mode = CURRENT_LIMIT;
            }
#endif
        }
        // 電流制限・ジャーク区間の制御
        if (mode == CURRENT_LIMIT || mode == JERK_MODE)
        {
            static double before_cl = 0;
			// 電流制限モードのタイムステップを待って制御
            if (now >= (before_cl + STEP_CL))
            {
                constexpr double step_cl = STEP_CL;
                before_cl = now;
				// PI制御計算
#if 0
                PI_CL.err = refT - allT;
                PI_CL.integral += PI_CL.err * PI_CL.T;
				PI_CL.diff = (PI_CL.err - PI_CL.err_before) / PI_CL.T;
                double P = PI_CL.KP * PI_CL.err;
                double I = PI_CL.integral * PI_CL.KI;
				double D = PI_CL.diff * PI_CL.KD;
                DutyCL += P + I + D;

#else
                DutyCL += PI_CL.compute(refT - allT);
#endif
				DutyCL = clamp(DutyCL, PI_CL.lower, PI_CL.upper);
#if KP_SWITCH_FLAG
                if (dec_kp_f)
                {
                    ControleKP_CL(DutyCL, step_cl, &PI_CL, N);
                }
#endif
            }
			
#if BOOST_FLAG
            {
                if (DutyCL >= 1.09)
                {
                    mode = BOOST;
                    DutyCL = PI_CL.upper;
                    PI_BST.KP = KP_BST;
                    PI_BST.integral = 0;
                    PI_BST.err_before = PI_BST.err;
                }
            }
#endif
        }

#if BOOST_FLAG
        // 昇圧モードの制御
        if (mode == BOOST)
        {
            static double before_bst = 0;
			// 昇圧モードのタイムステップを待って制御
            if (now >= (before_bst + STEP_BST))
            {
                double step_bst = now - before_bst;
                before_bst = now;
#if 0
				PI_BST.err = refT - allT;
				double P = PI_BST.KP * PI_BST.err;
				double I = PI_BST.integral * PI_BST.KI;
				DutyBST += P + I;
#else
				DutyBST += PI_BST.compute(refT - allT);
#endif
				DutyBST = clamp(DutyBST, 0, 0.95);
#if KP_SWITCH_FLAG
                ControleKP_BST(DutyBST, step_bst, &PI_BST, N);
#endif
            }
        }
        
#endif

        // PWM出力設定
        output::duty_cl.set(DutyCL);
        output::duty_bst.set(DutyBST);
    }
#if 1
    // データ出力（停止以外のモード時）
    if(mode != NORMAL_DECELERATION){
        static double t = 0;
        t += step*1e5;
        if(mode == STOPPED){
            printf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", 
				(int)(t/10),
				mode,
				0,
				0,
				(int)(refT*100),
				0,
				(int)(PI_CL.KP*1000),
				(int)(PI_CL.KI*1000),
				(int)(DutyCL*4000),
				(int)(PI_BST.KP*1000),
				(int)(PI_BST.KI*1000),
				(int)(DutyBST*4000), 
				(int)(input_t*1000)
			);
        }
        else{
            printf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", 
				(int)(t/10),
				mode,
				(int)(N*10),
				(int)(allT*1000),
				(int)(refT*100),
				(int)(d*100),
				(int)(PI_CL.KP*1000),
				(int)(PI_CL.KI*1000),
				(int)(DutyCL*4000),
				(int)(PI_BST.KP*1000),
				(int)(PI_BST.KI*1000),
				(int)(DutyBST*4000), 
				(int)(input_t*1000)
			);
        }
    }
#endif
    output::LED.write(0); // LED消灯
    return true;
}