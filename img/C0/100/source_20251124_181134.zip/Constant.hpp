#ifndef CONSTANT_H
#define CONSTANT_H

constexpr double WHEEL_R = 0.18;				// タイヤ半径
constexpr double IPM_Inertia = 198e-4;		// IPMの慣性モーメント
constexpr double Servo_Inertia = 6.0e-4;		// サーボモータの慣性モーメント
constexpr double Cupling_Inertia = 710.6e-6; // カプリングの慣性モーメント
constexpr double GEAR = 10;					// ギア比
constexpr double Flywheel_Tc = 0.55;	  // フライホイールの定トルク
constexpr double Flywheel_K1 = 0.0025; // フライホイールのトルク損失係数
constexpr double WHEER_INERTIA = IPM_Inertia + Servo_Inertia; // フライホイールの慣性モーメント
constexpr double DPT = WHEEL_R / (WHEER_INERTIA * GEAR); // 減速度とトルクの変換係数
constexpr double TPD = 1 / DPT;							// トルクと減速度の変換係数
constexpr double R_EDLC = 4.55;	// EDLCの内部抵抗

constexpr double PICO_FREQ = 125e6; // Picoのクロック周波数

constexpr double PI = 3.14159265358979323846; // 円周率

#endif // CONSTANT_H