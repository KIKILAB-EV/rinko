#include "functions.hpp"

/**
 * PID制御器クラス
 * 比例(P)・積分(I)・微分(D)制御を実装したフィードバック制御器
 */
struct PIDControl
{
    // 制御パラメータ
    double err, integral, diff;     // 偏差、積分値、微分値
    double KP, KI, KD, T;          // 比例ゲイン、積分ゲイン、微分ゲイン、サンプリング周期[s]
    double lower, upper;           // 出力制限値（下限、上限）
    double err_before;            // 前回の偏差（微分計算用）

    bool init_flag = false; // 初期化フラグ

    /**
     * PID制御器のコンストラクタ
     * @param kp 比例ゲイン
     * @param ki 積分ゲイン  
     * @param kd 微分ゲイン
     * @param t サンプリング周期[s]
     * @param lower 出力下限値
     * @param upper 出力上限値
     */
    PIDControl(double kp, double ki, double kd, double t, double lower, double upper)
    {
        // ゲインパラメータ設定
        this->KP = kp;
        this->KI = ki;
        this->KD = kd;

        this->T = t;  // サンプリング周期設定

        // 出力制限値設定
        this->lower = lower;
        this->upper = upper;

        // 内部変数初期化
        this->err = 0;      // 偏差初期化
        this->integral = 0; // 積分値初期化
        this->diff = 0;     // 前回偏差初期化（微分計算用）
    }

	/**
	 * PID制御計算を実行
	 * @param e 現在の偏差（目標値 - 現在値）
	 * @return 制御出力値
	 */
    double compute(double e)
    {
		// 偏差更新
		err = e;
        if (!init_flag)
        {
            err_before = err;
            init_flag = true;
        }

        // 積分項計算（台形積分）
        integral += (err) * T;
        
        // 微分項計算（後退差分）
        diff = (err - err_before) / T;

        // PID各項計算
        double P = KP * err;        // 比例項：現在の偏差に比例
        double I = KI * integral;   // 積分項：偏差の累積に比例
        double D = KD * diff;       // 微分項：偏差の変化率に比例
        err_before = err;
        // PID制御出力（各項の合計）
        return P + I + D;
    }
};