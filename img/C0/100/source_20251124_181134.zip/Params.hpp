#ifndef PARAMS_H
#define PARAMS_H

#define C100 1

#if C100
constexpr double START_N = 1000; // 制御開始回転数
constexpr double KP_CL1 = 0.02;	// 充電回路の比例ゲイン1
constexpr double KP_CL2 = 0.0; // 充電回路の比例ゲイン2
constexpr double KI_CL = 0.10;	// 充電回路の時定数
constexpr double KP_BST = 0.007; // 昇圧回路の比例ゲイン
constexpr double KI_BST = 0.05; // 昇圧回路の時定数
#else
constexpr double START_N = 1000; // 制御開始回転数
constexpr double KP_CL1 = 0.2;	// 充電回路の比例ゲイン1
constexpr double KP_CL2 = 0.0; // 充電回路の比例ゲイン2
constexpr double KI_CL = 0.10;	// 充電回路の時定数
constexpr double KP_BST = 0.3; // 昇圧回路の比例ゲイン
constexpr double KI_BST = 0.05; // 昇圧回路の時定数
#endif

constexpr double PWM_FREQ_CL = 500; // PWM搬送波(電流制限)
constexpr double PWM_FREQ_BST = 500; // PWM搬送波(昇圧)

constexpr double R_PROTECT = 10; // 保護抵抗

constexpr double SAMPLE_FREQ = 1000;	   // サンプリング周波数
constexpr double STEP = 1.0 / SAMPLE_FREQ; // 計算ステップ時間

constexpr double STEP_CL = 1 / PWM_FREQ_CL;	  // 電流制限モード時の計算ステップ時間
constexpr double STEP_BST = 1 / PWM_FREQ_BST; // 昇圧モード時の計算ステップ時間

constexpr double DELAY_D = 0.04; // 減速度計算の遅延時間

constexpr double JERK = 2.94; // ジャーク

#endif // PARAMS_H