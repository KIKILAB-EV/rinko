#ifndef ADC_H
#define ADC_H
#include "hardware/adc.h"

// ADC関連定数
constexpr double ADC_REFERENCE = 3.3;  // ADC基準電圧 [V]
constexpr int    ADC_RESOLUTION = 12;  // ADC分解能 [bit]

/**
 * 内蔵ADC制御クラス
 * Raspberry Pi Picoの内蔵12bit ADCを制御するためのクラス
 */
class ADC{
    int m_id = 0;    // ADCチャンネル番号（0-2）
    int m_gpio;      // 対応するGPIOピン番号

public:
    /**
     * ADCチャンネルの初期化
     * @param id ADCチャンネル番号（0:GPIO26, 1:GPIO27, 2:GPIO28）
     */
    void init(uint id){
        m_id = id;
        // チャンネル番号からGPIOピン番号を決定
        m_gpio = id == 0 ? 26 : id == 1 ? 27 : 28;
        // 指定したGPIOピンをADC入力として初期化
        adc_gpio_init(m_gpio);
    }

    /**
     * ADC値を読み取り、電圧値に変換
     * @return 電圧値 [V]（0.0 - 3.3V）
     */
    double read(){
        // ADC入力チャンネルを選択
        adc_select_input(m_id);
        
        // デジタル値から電圧値への変換係数計算
        // 12bit ADC: 0-4095 → 0.0-3.3V
        constexpr double conversion_factor = ADC_REFERENCE / ((1 << ADC_RESOLUTION)-1);
        
        // ADC値を読み取り、電圧値に変換して返す
        return adc_read() * conversion_factor;
    }
};
#endif // ADC_H